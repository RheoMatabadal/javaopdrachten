
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JPanel;



/**
 *
 * @author Kay-G
 */
public class herpanel extends JPanel {
    
    private JTextField txthyp, txtuitkomst;
    private JButton btnbereken;
    private JLabel lblhyp, lbluitkomst ;
    
    public herpanel () {
        
        setLayout(null);
        
        txthyp = new JTextField(10);
        txtuitkomst = new JTextField(10);
        
      lblhyp = new JLabel("Hypotheek");
      lbluitkomst = new JLabel("Uitkomst");
      
      lblhyp.setBounds(120, 50, 90, 20);
      txthyp.setBounds(180, 50, 90, 20);
      lbluitkomst.setBounds(120, 80, 90, 20);
      txtuitkomst.setBounds(180, 80, 90, 20);
      btnbereken.setBounds(180, 110, 90, 20);
      
      add(btnbereken);
      add(txthyp);
      add(txtuitkomst);
      add(lblhyp);
      add(lbluitkomst);
      
     btnbereken.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               double hypotheek = Double.parseDouble(txthyp.getText());
                double formule;
                double restant;
                if(hypotheek<= 1500){
                    formule = hypotheek + hypotheek* 0.20;
                    txtuitkomst.setText (String.format("%8.2f" , formule));
                    
                }
                else if (hypotheek>1500 && hypotheek <= 3000){
                    
                    restant = hypotheek - 1500;
                    formule = ((hypotheek + 1500*0.20)+(restant + hypotheek*0.30));
                    txtuitkomst.setText (String.format("%8.2f" , formule)); 
                    
                }
                
                else if (hypotheek >3000 && hypotheek <= 4500){
                    
                    restant = hypotheek - 3000;
                    formule = ((hypotheek + 1500*0.20)+(hypotheek + 1500*0.30)+(restant*0.50));
                    txtuitkomst.setText (String.format("%8.2f" , formule));
                    
                }
                else if (hypotheek > 4500 && hypotheek <=6000){
                    
                    restant = hypotheek - 4500;
                    formule = ((hypotheek + 1500*0.20)+(hypotheek + 1500*0.30)+(hypotheek + 1500*0.50)+(restant*0.75));
                    txtuitkomst.setText (String.format("%8.2f" , formule));
            }
                
                
            }
            
        });
}
}     
                
                
                
                
                
                
                
                
            
    
              



    
