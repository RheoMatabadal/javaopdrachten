import javax.swing.*;


/**
 *
 * @author Kay-G
 */
public class Javaher extends JFrame {

   
    public static void main(String[] args) {
        // TODO code application logic here
        
        JFrame frame = new Javaher();
        frame.setSize  (600,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Bank");
        
        frame.setContentPane (new herpanel());
        frame.setVisible(true);
    }
    
}
